import express from 'express';
import Disaster from '../models/disaster.js';

const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const disasters = await Disaster.find();
    res.status(200).json(disasters);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

router.post('/', async (req, res) => {
  const disaster = new Disaster({
    name: req.body.name,
    type: req.body.type,
    location: req.body.location,
    severity: req.body.severity,
    startDate: req.body.startDate,
    affectedAreas: req.body.affectedAreas
  });

  try {
    const newDisaster = await disaster.save();
    res.status(201).json(newDisaster);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

export default router;
