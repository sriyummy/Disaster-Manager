import mongoose from 'mongoose';

const disasterSchema = new mongoose.Schema({
  name: String,
  type: String,
  location: {
    type: { type: String, enum: ['Point'], required: true },
    coordinates: { type: [Number], required: true }
  },
  severity: Number,
  startDate: Date,
  affectedAreas: [String],
});

disasterSchema.index({ location: '2dsphere' });

const Disaster = mongoose.model('Disaster', disasterSchema);
export default Disaster;
